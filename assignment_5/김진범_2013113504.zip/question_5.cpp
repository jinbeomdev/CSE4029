/*
Student ID : 2013113504
Student Name : KIM JIN BEOM

Question 5:
Chameleon Probelm

On one island, there are a red, b yellow, and c neon chameleon.
Let's say that when two chameleons meet, they turn into a third color.
For example, when a red and yellow chameleon meet, they turn into neon
chameleons, respectively.

1)At what moment can all chameleons be unified in one color on the island?
if possible, write down the strategy and the time it takes to get there.
However, the values of a, b, and c are different each other!
a + 2b = c - b
t = a + 2b + b

2)if a=1, b=3, c=5, would it be possible for the chameleon of the island
to be unified in one color?
1 + 6 = 5 - 3
7 is not equal with 2
It is impossible.

*/