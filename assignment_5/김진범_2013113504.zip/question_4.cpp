/*
Question 4:
Bacterial vs virus Problem:

There are n bacteria and one virus on the food plate. Every minute,
each virus kills one bacterium, and the remaining viruses and bacteria
replicate. If this process continues, what will be the last of the 
bacteria and viruses on the food plate? If all the bacteria die,
how long does it take for all the bacteria to die?

n/1
2(n-1)/2
2(2(n-1)-2)/4
2(2(2(n-1)-2)-4)/8
...
*/